#!/usr/bin/python
# -*- encoding: utf-8; py-indent-offset: 4 -*-

# Copyright: (c) 2022, Robin Gierse <robin.gierse@tribe29.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = r'''
---
module: folder

short_description: Manage folders in Checkmk.

# If this is part of a collection, you need to use semantic versioning,
# i.e. the version is of the form "2.5.0" and not "2.4".
version_added: "0.0.1"

description:
- Create and delete folders within Checkmk.

extends_documentation_fragment: [tribe29.checkmk.common]

options:
    path:
        description: The full path to the folder you want to manage.
        required: true
        type: str
    title:
        description: The title of your folder.
        required: true
        type: str
    state:
        description: The state of your folder.
        type: str
        default: present
        choices: [present, absent]

author:
    - Robin Gierse (@robin-tribe29)
'''

EXAMPLES = r'''
# Pass in a message
- name: Test with a message
  tribe29.checkmk.folder:
    name: hello world

# pass in a message and have changed true
- name: Test with a message and changed output
  tribe29.checkmk.folder:
    name: hello world
    new: true

# fail the module
- name: Test failure of the module
  tribe29.checkmk.folder:
    name: fail me
'''

RETURN = r'''
# These are examples of possible return values, and in general should use other names for return values.
original_message:
    description: The original name param that was passed in.
    type: str
    returned: always
    sample: 'hello world'
message:
    description: The output message that the test module generates.
    type: str
    returned: always
    sample: 'goodbye'
'''

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.urls import fetch_url

def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = dict(
        server_url=dict(type='str', required=True),
        site=dict(type='str', required=True),
        automation_user=dict(type='str', required=True),
        automation_secret=dict(type='str', required=True),
        path=dict(type='str', required=True),
        title=dict(type='str', required=True),
        state=dict(type='str', choices=['present', 'absent']),
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False,
        original_message='',
        message=''
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    if module.params['path'] is None:
        module.params['path'] = '/'
    if module.params['state'] is None:
        module.params['state'] = 'present'

    server_url=module.params['server_url']
    site=module.params['site']
    automation_user=module.params['automation_user']
    automation_secret=module.params['automation_secret']
    path=module.params['path'].replace('/', '~')
    title=module.params['title']
    state=module.params['state']

    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer '+automation_user+' '+automation_secret
        }

    api_endpoint = '/objects/folder_config/'+path
    url = server_url+site+"/check_mk/api/1.0"+api_endpoint
    params = {
        'parent': '/',  # ToDo: split path to distiguish name and parent
    }
    response, info = fetch_url(module, url, data=None, headers=headers, method='GET')
    if info['status'] == 200:
        folder_state = 'present'
        # module.exit_json(msg=folder_state)
    elif info['status'] == 404:
        folder_state = 'absent'
        # module.exit_json(msg=folder_state)
    else:
        module.fail_json(msg='Unable to call API: Status '+str(info['status']))

    if state == 'present' and folder_state == 'present':
        module.exit_json(changed=False)
    elif state == 'present' and folder_state == 'absent':
        api_endpoint = '/domain-types/folder_config/collections/all'
        params = {
            'name': title,  # ToDo: split path to distiguish name and parent
            'parent': '/',
            'title': title,  # ToDo: derive tile from path or use dedicated param?
            'attributes': {
                'tag_criticality': 'prod'
            }
        }
        url = server_url+site+"/check_mk/api/1.0"+api_endpoint

        # We will be using Ansible fetch_url method to call API requests. We don't want to
        # use Python requests as its best to use the utils provided by Ansible.
        response, info = fetch_url(module, url, module.jsonify(params), headers=headers, method='POST')
        # we receive status code 200 we will return it TRUE
        if info['status'] == 200:
            module.exit_json(changed=True)
        else:
           module.fail_json(msg='Unable to call API: Status '+str(info['status']))
    elif state == 'absent' and folder_state == 'absent':
        module.exit_json(changed=False)
    elif state == 'absent' and folder_state == 'present':
        api_endpoint = '/objects/folder_config/'+path
        url = server_url+site+"/check_mk/api/1.0"+api_endpoint
        # We will be using Ansible fetch_url method to call API requests. We don't want to
        # use Python requests as its best to use the utils provided by Ansible.
        response, info = fetch_url(module, url, data=None, headers=headers, method='DELETE')
        # we receive status code 200 we will return it TRUE
        if info['status'] == 204:
            module.exit_json(changed=True)
        else:
           module.fail_json(msg='Unable to call API: Status '+str(info['status']))



    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)
    # result['original_message'] = module.params['name']
    result['original_message'] = response
    result['message'] = 'goodbye'

    # module.exit_json(**result)

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    # if module.params['new']:
    #     result['changed'] = True

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result
    # if module.params['name'] == 'fail me':
    #     module.fail_json(msg='You requested this to fail', **result)

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
