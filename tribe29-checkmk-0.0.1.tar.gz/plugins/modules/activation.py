#!/usr/bin/python
# -*- encoding: utf-8; py-indent-offset: 4 -*-

# Copyright: (c) 2022, Robin Gierse <robin.gierse@tribe29.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = r'''
---
module: activation

short_description: Activate changes in Checkmk.

# If this is part of a collection, you need to use semantic versioning,
# i.e. the version is of the form "2.5.0" and not "2.4".
version_added: "0.0.1"

description:
- Activate changes within Checkmk.

extends_documentation_fragment: [tribe29.checkmk.common]

options:
    sites:
        description: The sites that should be activated.
        required: true
        type: str
    force_foreign_changes:
        description: Wheather to active foreign changes.
        default: False
        type: bool
    # state:
    #     description: The state of your host.
    #     type: str
    #     default: present
    #     choices: [present, absent]

author:
    - Robin Gierse (@robin-tribe29)
'''

EXAMPLES = r'''
# Pass in a message
- name: "Activate changes."
  tribe29.checkmk.activation:
      server_url: "http://localhost/"
      site: "my_site"
      automation_user: "automation"
      automation_secret: "$SECRET"
      force_foreign_changes: 'true'
      sites: "test"
'''

RETURN = r'''
# These are examples of possible return values, and in general should use other names for return values.
original_message:
    description: The original name param that was passed in.
    type: str
    returned: always
    sample: 'hello world'
message:
    description: The output message that the test module generates.
    type: str
    returned: always
    sample: 'goodbye'
'''

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.urls import fetch_url

def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = dict(
        server_url=dict(type='str', required=True),
        site=dict(type='str', required=True),
        automation_user=dict(type='str', required=True),
        automation_secret=dict(type='str', required=True),
        sites=dict(type='str', required=True),
        force_foreign_changes=dict(type='bool', default=False),
        # state=dict(type='str', choices=['present', 'absent']),
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False,
        original_message='',
        message=''
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    if module.params['force_foreign_changes'] is None:
        module.params['force_foreign_changes'] = False
    if module.params['sites'] is None:
        module.params['sites'] = {}  # ToDo: How to pass empty array of strings?

    server_url=module.params['server_url']
    site=module.params['site']
    automation_user=module.params['automation_user']
    automation_secret=module.params['automation_secret']
    sites=module.params['sites']
    force_foreign_changes=module.params['force_foreign_changes']

    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer '+automation_user+' '+automation_secret
        }

    params = {
        'force_foreign_changes': force_foreign_changes,
        'redirect': True,  # ToDo: Do we need this? Does it need to be configurable?
        # ToDo: make sites list iterable
        # 'sites': {
        #     'sitename'
        # }
    }

    api_endpoint = '/domain-types/activation_run/actions/activate-changes/invoke'
    url = server_url+site+"/check_mk/api/1.0"+api_endpoint
    response, info = fetch_url(module, url, module.jsonify(params), headers=headers, method='POST')
    # ToDo: Refactor evaluation to dictionary
    if info['status'] == 200:
        module.exit_json(changed=True, msg="Changes activated.")
    elif info['status'] == 204:  # ToDo: Undocumented return code?
        module.exit_json(changed=True, msg="Changes activated.")
    elif info['status'] == 302:
        module.exit_json(changed=True, msg="Redirected.")
    elif info['status'] == 422:
        module.exit_json(changed=False, msg="There are no changes to be activated.")
    elif info['status'] == 400:
        module.exit_json(failed=True, msg="Bad Request.")
    elif info['status'] == 401:
        module.exit_json(failed=True, msg="Unauthorized: There are foreign changes, which you may not activate, or you did not use <force_foreign_changes>.")
    elif info['status'] == 403:
        module.exit_json(failed=True, msg="Forbidden: Configuration via WATO is disabled.")
    elif info['status'] == 406:
        module.exit_json(failed=True, msg="Not Acceptable.")
    elif info['status'] == 409:
        module.exit_json(failed=True, msg="Conflict: Some sites could not be activated.")
    elif info['status'] == 415:
        module.exit_json(failed=True, msg="Unsupported Media Type.")
    elif info['status'] == 423:
        module.exit_json(failed=True, msg="Locked: There is already an activation running.")
    else:
        module.fail_json(msg='Unable to call API: Status '+str(info['status']))

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)
    # result['original_message'] = module.params['name']
    result['original_message'] = response
    result['message'] = 'goodbye'

    # module.exit_json(**result)

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    # if module.params['new']:
    #     result['changed'] = True

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result
    # if module.params['name'] == 'fail me':
    #     module.fail_json(msg='You requested this to fail', **result)

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
