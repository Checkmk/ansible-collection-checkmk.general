# tribe29 Checkmk Collection

## This is a work in progress!
## Do not use until you know what you are doing!

---

We are completely reorganizing this repository. In the process we might even need to create new repositories or rename this one. Most of this work will happen in a dedicated branch until it is ready to be mainlined. Keep an eye on the progress here and feel free to contribute in any way. We will try to keep you posted as best as we can. Keep an eye on [this Checkmk forum post](https://forum.checkmk.com/t/checkmk-goes-ansible/25428) for updates.

## Notes

- https://docs.ansible.com/ansible/latest/dev_guide/developing_collections_structure.html
- https://docs.ansible.com/ansible/latest/user_guide/collections_using.html

---

Checkmk already provides the needed APIs to automate the 
configuration of your monitoring. With this project we want to create
and share roles and modules for ansible to simplify your first steps with automating Checkmk through Ansible.

# tribe29 Checkmk Collection
The Ansible Amazon Checkmk collection includes a variety of Ansible content to help automate the management of Checkmk instances. This collection is maintained by the Ansible cloud team.

Checkmk related modules and plugins supported by the Ansible community are in the [community.checkmk](https://github.com/ansible-collections/community.checkmk/) collection.

<!--start requires_ansible-->
## Ansible version compatibility

This collection has been tested against following Ansible versions: **>=2.9.10**.

Plugins and modules within a collection may be tested with only specific Ansible versions.
A collection may contain metadata that identifies these versions.
PEP440 is the schema used to describe the versions of Ansible.
<!--end requires_ansible-->

## Included content

<!--start collection content-->
### Inventory plugins
Name | Description
--- | ---
[tribe29.checkmk.ec2](https://github.com/ansible-collections/tribe29.checkmk/blob/main/docs/tribe29.checkmk.ec2_inventory.rst)|EC2 inventory source
[tribe29.checkmk.rds](https://github.com/ansible-collections/tribe29.checkmk/blob/main/docs/tribe29.checkmk.rds_inventory.rst)|rds instance source

### Lookup plugins
Name | Description
--- | ---
[tribe29.checkmk.account_attribute](https://github.com/ansible-collections/tribe29.checkmk/blob/main/docs/tribe29.checkmk.account_attribute_lookup.rst)|Look up Checkmk account attributes.
[tribe29.checkmk.secret](https://github.com/ansible-collections/tribe29.checkmk/blob/main/docs/tribe29.checkmk.secret_lookup.rst)|Look up secrets stored in Checkmk Secrets Manager.

### Modules
Name | Description
--- | ---
[tribe29.checkmk.az_info](https://github.com/ansible-collections/tribe29.checkmk/blob/main/docs/tribe29.checkmk.az_info_module.rst)|Gather information about availability zones in Checkmk.
[tribe29.checkmk.caller_info](https://github.com/ansible-collections/tribe29.checkmk/blob/main/docs/tribe29.checkmk.caller_info_module.rst)|Get information about the user and account being used to make Checkmk calls.
<!--end collection content-->

## Installing this collection

You can install the Checkmk collection with the Ansible Galaxy CLI:

    ansible-galaxy collection install tribe29.checkmk

You can also include it in a `requirements.yml` file and install it with `ansible-galaxy collection install -r requirements.yml`, using the format:

```yaml
---
collections:
  - name: tribe29.checkmk
```

The python module dependencies are not installed by `ansible-galaxy`.  They can
be manually installed using pip:

    pip install requirements.txt

or:

    pip install boto boto3 botocore

## Using this collection


You can either call modules by their Fully Qualified Collection Namespace (FQCN), such as `tribe29.checkmk.api`, or you can call modules by their short name if you list the `tribe29.checkmk` collection in the playbook's `collections` keyword:

```yaml
---
    <Example Playbook>
```
### See Also:

* [Amazon Web Services Guide](https://docs.ansible.com/ansible/latest/scenario_guides/guide_aws.html)
* [Ansible Using collections](https://docs.ansible.com/ansible/latest/user_guide/collections_using.html) for more details.

## Contributing to this collection

We welcome community contributions to this collection. If you find problems, please open an issue or create a PR against the [Amazon Checkmk collection repository](https://github.com/ansible-collections/tribe29.checkmk). See [Contributing to Ansible-maintained collections](https://docs.ansible.com/ansible/devel/community/contributing_maintained_collections.html#contributing-maintained-collections) for more details.

You can also join us on:

- IRC - the ``#ansible-checkmk`` [irc.libera.chat](https://libera.chat/) channel

### More information about contributing

- [Ansible Community Guide](https://docs.ansible.com/ansible/latest/community/index.html) - Details on contributing to Ansible
- [Contributing to Collections](https://docs.ansible.com/ansible/devel/dev_guide/developing_collections.html#contributing-to-collections) - How to check out collection git repositories correctly
- [Guidelines for Ansible Amazon Checkmk module development](https://docs.ansible.com/ansible/latest/dev_guide/platforms/guidelines.html)
- [Getting Started With Checkmk Ansible Module Development and Community Contribution](https://www.ansible.com/blog/getting-started-with-checkmk-ansible-module-development)

## Release notes
<!--Add a link to a changelog.rst file or an external docsite to cover this information. -->

## Roadmap

<!-- Optional. Include the roadmap for this collection, and the proposed release/versioning strategy so users can anticipate the upgrade/update cycle. -->

## More information

- [Ansible Collection overview](https://github.com/ansible-collections/overview)
- [Ansible User guide](https://docs.ansible.com/ansible/latest/user_guide/index.html)
- [Ansible Developer guide](https://docs.ansible.com/ansible/latest/dev_guide/index.html)
- [Ansible Community code of conduct](https://docs.ansible.com/ansible/latest/community/code_of_conduct.html)

## Licensing

GNU General Public License v3.0 or later.

See [COPYING](https://www.gnu.org/licenses/gpl-3.0.txt) to see the full text.
