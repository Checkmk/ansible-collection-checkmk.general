# Notes

## Questions
- Namining

## Ressources:
- https://docs.ansible.com/ansible/latest/dev_guide/developing_collections_structure.html
- https://docs.ansible.com/ansible/latest/user_guide/collections_using.html

# Naming

## Namespace
- Do we want to register an official namespace?
- tribe29 or checkmk?
- FQCN: tribe29.checkmk?
- Roles: checkmk.agent or tribe29.agent
